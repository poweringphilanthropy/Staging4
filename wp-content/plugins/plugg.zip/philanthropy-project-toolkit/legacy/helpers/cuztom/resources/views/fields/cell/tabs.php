<tr class="cuztom-cell cuztom-tabs">
    <td class="cuztom-field" id="<?php echo $tabs->getId(); ?>" colspan="2">
        <?php echo $tabs->output(); ?>
    </td>
</tr>
