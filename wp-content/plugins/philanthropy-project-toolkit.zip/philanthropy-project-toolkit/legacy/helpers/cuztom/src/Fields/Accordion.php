<?php

namespace Gizburdt\Cuztom\Fields;

use Gizburdt\Cuztom\Support\Guard;

Guard::directAccess();

class Accordion extends Tabs
{
    /**
     * Base.
     * @var mixed
     */
    public $view = 'accordion';
}
