<?php
/**
 * This template was deprecated in 1.2.3. Use campaign-loop/donate-link.php instead.
 *
 * @deprecated
 */

charitable_template( 'campaign-loop/donate-link.php', $view_args );