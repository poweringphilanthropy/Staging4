<?php
/**
 * The template used to display the donation amount form header.
 *
 * @author  Studio 164a
 * @since   1.0.0
 * @version 1.0.0
 */
?>
<h3 class="charitable-form-header"><?php _e( 'Your Donation', 'charitable' ) ?></h3>